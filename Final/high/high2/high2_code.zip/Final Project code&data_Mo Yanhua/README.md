# LlamaIndex-Evolve: Self-Learning from Model Disagreements

CSS5120: Computational Linguistics — Final Project

---

## Project Overview

LlamaIndex-Evolve extends LlamaIndex with a closed self-learning loop.
Three Qwen worker models independently classify products; when they disagree
(cosine similarity < 0.85), a Qwen-max supervisor generates a structured
JSON experience stored in a dynamic LlamaIndex-managed ChromaDB index.
Future queries retrieve and inject these experiences, enabling continuous
improvement without model retraining.

---

## File Structure

```
├── llamaindex_evolve_final.py      # Main experiment code
├── figures/
│   └── real_experiment_results.png # 4-round experiment results figure
├── data/
│   ├── products.csv                # 60 product descriptions with ground truth
│   ├── experiment_results.csv      # Per-product results with disagreement details
│   └── round_summary.csv          # Per-round aggregated statistics
└── README.md
```

---

## Dependencies

```bash
pip install llama-index \
            llama-index-vector-stores-chroma \
            llama-index-embeddings-huggingface \
            llama-index-llms-openai-like \
            openai \
            chromadb \
            sentence-transformers \
            matplotlib
```

Tested on Python 3.10+.

---

## Models used

| Role       | Model       | Purpose                          |
|------------|-------------|----------------------------------|
| Worker A   | qwen-turbo  | Fast, bias toward liquid→F&B     |
| Worker B   | qwen-plus   | Mid, bias toward container→Kitchen |
| Worker C   | qwen-long   | Long-ctx, bias toward smart→Electronics |
| Supervisor | qwen-max    | Disagreement analysis + experience generation |

---

## How to Run

### Jupyter Notebook (recommended)

1. Open Jupyter: `jupyter notebook`
2. Open `llamaindex_evolve_final.py`
3. Run Cell 1 (uncomment the pip install line), then restart kernel
4. Run Cells 3–12 in order

