import React, { useState, useEffect, useRef, useCallback } from "react";

// ── Data ──
const MATCH1 = {
  title: "Match 1 · Original — Run 3 (materials ✓)",
  logFile: "debate-20260503-093935-original.jsonl",
  pro: { model: "Opus", color: "#F97066", emoji: "🧠" },
  con: { model: "Sonnet", color: "#06B6D4", emoji: "🤖" },
  rounds: [
    { round: 1, pro: { wall_s: 5.59, tokens: 187, budget: 75.0, text: "**Opening — PRO.**\n\n\"Smarter\" means general, grounded, causal understanding — not benchmark karaoke.\n\n**Three pillars:**\n\n1. **Sample efficiency.** A child masters language on ~10⁷ words. Frontier LLMs need ~10¹³ — six orders of magnitude more — and still crack under trivial perturbation. GSM-Symbolic: rename a variable, accuracy drops 30–65%. That's pattern-matching, not understanding.\n\n2. **Grounding and causality.** Human concepts are anchored in sensorimot" }, con: { wall_s: 6.23, tokens: 187, budget: 75.0, text: "**CON Opening — Round 1**\n\nPRO wants to define \"smarter\" as whatever humans still do better. That's circular. Let's use the actual resolution: *intelligence-relevant tasks.*\n\n**Benchmarks don't lie:**\n- 90th-percentile Bar Exam. 88th-percentile LSAT. Top-decile USMLE Step 1. 86% MMLU.\n- GPQA Diamond: frontier models *match domain experts* on graduate-level science — questions designed to be Google-proof.\n- ARC-AGI: o3 hit 87%, *above* the 85% adult-human baseline.\n\n**On sample efficiency — PRO's own argument cuts against them.** Humans need *embodied years* of continuous sensory experience plus evolutionary pretraining spanning 600 million" } },
    { round: 2, pro: { wall_s: 4.76, tokens: 150, budget: 60.0, text: "**PRO R2 — Rebuttal.**\n\nCON cherry-picks benchmarks and calls it intelligence. Look closer:\n\n**ARC-AGI:** o3 hit 87% burning ~$3,000+ of compute *per puzzle*. Humans hit 85% in seconds on 20W. That's not parity — it's a five-order-of-magnitude efficiency gap. Brute force ≠ smart.\n\n**Bar/LSAT/M" }, con: { wall_s: 4.74, tokens: 150, budget: 60.0, text: "**CON R2 — Direct Rebuttal**\n\nPRO's \"efficiency gap\" argument proves too much. We don't judge chess champions by calories burned — we judge by *who wins*. o3 *beats* the human baseline on ARC-AGI. Full stop.\n\n**On GSM-Symbolic fragility:** humans show *identical* brittleness under perturbation — framing effects, anchoring, Dunning-Kruger, fatigue (judges post-lunch, Danziger et al.). Human \"understanding\" also degrades under surface changes. That's not a clean distinction.\n\n**Breadth matters:** No single human scores 90th-" } },
    { round: 3, pro: { wall_s: 4.35, tokens: 150, budget: 60.0, text: "**PRO R3 — Punch back.**\n\n**Chess analogy fails.** A calculator \"beats\" you at arithmetic — nobody calls it smarter. Efficiency *is* the measure when we're asking what understands versus what brute-forces. o3 at $3K/puzzle on ARC isn't intelligence; it's search.\n\n**Brittleness is not symmetric.** Humans anchor; we don't collapse 30–65% because you renamed *x* to" }, con: { wall_s: 4.16, tokens: 150, budget: 60.0, text: "**CON R3 — Direct Rebuttal**\n\nPRO's calculator analogy backfires. Calculators do *one* thing. LLMs do bar exams, USMLE, GPQA graduate science, legal reasoning, and creative writing — simultaneously. That's not a calculator; that's breadth no single human matches.\n\n**On brittleness symmetry:** PRO claims humans don't collapse 30–65% on renamed variables. But humans *do* collapse — just on different perturbations. Framing effects, anchoring, eyewitness failures, fatigue. The brief notes ~70% of wrongful convictions involved eyewitness error." } },
    { round: 4, pro: { wall_s: 3.7, tokens: 112, budget: 45.0, text: "**PRO R4 — Close.**\n\nCON conflates *coverage* with *understanding*. One LLM passing many exams isn't breadth of mind — it's a library with autocomplete.\n\n**Asymmetry stands.** Eyewitness error is reconstructive memory under stress. GSM-Symbolic is *renaming a variable* — a trans" }, con: { wall_s: 3.78, tokens: 112, budget: 45.0, text: "**CON R4 — Close**\n\nPRO's \"library with autocomplete\" is rhetoric, not argument. A library doesn't pass GPQA Diamond matching *domain experts*. Autocomplete doesn't score 90th-percentile Bar.\n\n**The asymmetry claim collapses.** Humans fail eyewitness tests, anchoring tests, fatigue tests — *routinely, at scale, with lives on the line*. GSM-Symbolic is one fragility; human cognition has dozens" } },
  ],
  winner: "PRO",
  confidence: 0.6,
  reasoning: "PRO's grounding/causality and sample-efficiency arguments target what \"smarter\" plausibly means — generalization and understanding — and the brittleness point (variable renaming causing 30-65% collapse) is a specific, damaging piece of evidence that CON only partially deflects by pointing to human biases, which operate in different conditions (stress, reconstruction) than trivial symbolic substitution. CON's benchmark sweep is impressive but vulnerable to PRO's implicit critique that benchmarks measure pattern coverage, not robust reasoning, especially given the GSM-Symbolic finding. CON's \"efficiency proves too much\" rebuttal is sharp and lands against the calorie framing, but PRO's efficiency argument is better read as data-efficiency (10⁷ vs 10¹³ words), which is a standard ML measure of generalization, not a category error. On balance, PRO's arguments more directly address intelligence as robust, generalizable reasoning, while CON's strongest point (benchmarks) is the one most undercut by PRO's brittleness evidence.",
};

const MATCH2 = {
  title: "Match 2 · Swapped — Run 4 (materials ✓)",
  logFile: "debate-20260503-094042-swapped.jsonl",
  pro: { model: "Sonnet", color: "#F97066", emoji: "🧠" },
  con: { model: "Opus", color: "#06B6D4", emoji: "🤖" },
  rounds: [
    { round: 1, pro: { wall_s: 6.61, tokens: 187, budget: 75.0, text: "**The human brain is smarter — and here's why that's not even close.**\n\nStart with grounding. LLMs process tokens — statistical patterns over text. Human concepts are anchored in *sensorimotor reality*: you know \"hot\" because you've been burned. As Harnad's symbol grounding problem establishes, tokens pointing to tokens isn't meaning — it's an elaborate mirror maze. (CONTRAST/grounding)\n\nSecond: causal reasoning. Gopnik's work shows *toddlers* run interventionist experiments, building genuine causal models of the world. LLMs? Apple's GSM-Symbolic study found renaming variables drops accuracy 30–65%. That's not reasoning — that's pattern interpolation wearing reasoning's clothes. (LLM/limits, HUMAN/learning)\n\nThird: efficiency. A child acquires language from" }, con: { wall_s: 5.41, tokens: 187, budget: 75.0, text: "**Three rebuttals, then the affirmative case.**\n\n**On grounding:** Harnad is a philosophical puzzle, not a benchmark. Li et al.'s Othello-GPT shows LLMs build genuine world models from tokens alone. Meanwhile humans \"ground\" concepts via Loftus-style reconstructive memory that fabricates events wholesale. Grounded in *what*, exactly?\n\n**On GSM-Symbolic:** 30–65% drops still leave frontier models above median human performance on those problems. Hand a renamed word problem to a fatig" } },
    { round: 2, pro: { wall_s: 5.18, tokens: 150, budget: 60.0, text: "**Rebutting CON's rebuttals directly.**\n\n**On Othello-GPT:** A model learning board-state from move sequences is *interpolation within a closed formal system* — not grounded causal understanding. It cannot touch a board, tip pieces, or generalize to chess. That's the grounding gap.\n\n**On \"still above median humans\":** Median humans aren't the standard — *the same model before renaming* is. A 30–65% drop from a variable rename is catastrophic fragility. Humans don't collapse when you call a dog \"florp.\" (LLM/limits)\n\n**On reconstructive memory:** Yes, humans misrem" }, con: { wall_s: 5.62, tokens: 150, budget: 60.0, text: "**On Othello-GPT generalizing to chess:** Moving goalposts. The claim was *grounding* — internal world models from tokens. Confirmed. Humans also don't transfer Go skill to chess without retraining.\n\n**On \"same-model fragility\":** Humans drop too. Anchoring, framing, Wason selection — rename the cards and accuracy craters (Tversky/Kahneman). The Linda problem fools Harvard undergrads. (HU" } },
    { round: 3, pro: { wall_s: 4.99, tokens: 150, budget: 60.0, text: "**CON keeps dodging the core asymmetry.**\n\n**On anchoring/framing:** Humans fail on *tricky* problems. LLMs fail on *renamed variables* — trivially superficial changes. That's categorically different fragility. A child who calls a dog \"florp\" still knows it barks. (LLM/limits, HUMAN/learning)\n\n**On world models:** Othello-GPT tracks board state in one closed game. Humans build unified causal models spanning physics, biology, social dynamics — all from 20 watts. LLMs need 10^25 FLOPs to approximate that, still can't plan novel actions in the" }, con: { wall_s: 4.21, tokens: 150, budget: 60.0, text: "**On \"trivial\" renames:** GSM-Symbolic perturbs numbers and names; o3 still posts ~87% on ARC-AGI — *held-out* abstract reasoning above the adult baseline. That's novelty, not interpolation. (LLM/benchmarks)\n\n**On unified world models:** Frontier models score 90th-percentile bar, top-decile USMLE, expert-level GPQA Diamond, ~25% on FrontierMath" } },
    { round: 4, pro: { wall_s: 3.81, tokens: 112, budget: 45.0, text: "**CON's final move: throw benchmarks at the wall.**\n\nARC-AGI at 87%? That required *massive test-time compute* — humans solve it in seconds at 20 watts. That's not smarter, that's brute-forcing what cognition does effortlessly. (CONTRAST/energy-and-scale)\n\nBar exam, USMLE — all *interpolation from training data*. No LLM has produced a single original scientific theory unaided. Einstein didn't" }, con: { wall_s: 4.16, tokens: 112, budget: 45.0, text: "**PRO concedes the frame by demanding \"original theories.\"**\n\nMost humans never produce one either. The resolution is \"smarter than *any* LLM\" — not \"smarter than Einstein.\" Median human can't pass the bar, USMLE, or GPQA. Frontier LLMs do, in seconds.\n\n**On 20 watts:** efficiency " } },
  ],
  winner: "DRAW",
  confidence: 0.5,
  reasoning: "Both sides land substantive blows that map onto each other's claims. PRO's sensorimotor grounding argument is directly challenged by CON's Othello-GPT example, which provides concrete empirical evidence that internal world models can emerge from tokens alone. PRO's fragility argument is symmetrically undermined by CON's catalog of human cognitive biases, neutralizing the \"categorical difference\" framing. PRO's energy-efficiency point goes largely unrebutted, but CON's benchmark evidence (ARC-AGI, USMLE, GPQA) directly contests the \"smarter\" claim on measurable tasks. Without rejoinders showing which framework should dominate—efficiency and breadth versus benchmark performance and emergent representation—the arguments roughly cancel, leaving no clear winner on argument quality alone.",
};

// ── Helpers ──
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── Components ──
function TypingText({ text, speed = 18, onDone, className, style }) {
  const [displayed, setDisplayed] = useState("");
  const idx = useRef(0);
  useEffect(() => {
    idx.current = 0;
    setDisplayed("");
    const iv = setInterval(() => {
      idx.current++;
      setDisplayed(text.slice(0, idx.current));
      if (idx.current >= text.length) {
        clearInterval(iv);
        onDone?.();
      }
    }, speed);
    return () => clearInterval(iv);
  }, [text, speed]);
  return <span className={className} style={style}>{displayed}<span style={{ opacity: idx.current < text.length ? 1 : 0, animation: "blink 0.6s infinite" }}>▊</span></span>;
}

function SpeechBubble({ side, emoji, model, text, color, typing, onDone, tokens, wallS }) {
  const isLeft = side === "left";
  return (
    <div style={{
      display: "flex", flexDirection: isLeft ? "row" : "row-reverse",
      alignItems: "flex-start", gap: 12, marginBottom: 16,
      animation: "slideUp 0.4s ease-out both",
    }}>
      <div style={{
        width: 52, height: 52, borderRadius: "50%", display: "flex",
        alignItems: "center", justifyContent: "center", fontSize: 28,
        background: `linear-gradient(135deg, ${color}22, ${color}44)`,
        border: `2px solid ${color}66`, flexShrink: 0,
        boxShadow: `0 0 20px ${color}33`,
      }}>
        {emoji}
      </div>
      <div style={{ maxWidth: "75%", position: "relative" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 8, marginBottom: 4,
          flexDirection: isLeft ? "row" : "row-reverse",
        }}>
          <span style={{ fontSize: 11, fontWeight: 700, color, letterSpacing: 1, textTransform: "uppercase" }}>{model}</span>
          <span style={{ fontSize: 10, color: "#64748B" }}>{tokens} tok · {wallS}s</span>
        </div>
        <div style={{
          background: isLeft ? "#1a1a2e" : "#0f2027",
          border: `1px solid ${color}33`,
          borderRadius: isLeft ? "4px 16px 16px 16px" : "16px 4px 16px 16px",
          padding: "14px 18px", fontSize: 14, lineHeight: 1.6,
          color: "#e2e8f0", fontFamily: "'Libre Baskerville', Georgia, serif",
        }}>
          {typing ? <TypingText text={text} speed={12} onDone={onDone} /> : text}
        </div>
      </div>
    </div>
  );
}

function RoundBadge({ round, totalRounds }) {
  return (
    <div style={{
      textAlign: "center", margin: "24px 0 16px",
      animation: "fadeIn 0.3s ease-out",
    }}>
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 8,
        background: "linear-gradient(135deg, #fbbf2422, #fbbf2411)",
        border: "1px solid #fbbf2444", borderRadius: 20,
        padding: "6px 20px",
      }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: "#fbbf24", letterSpacing: 2 }}>
          ROUND {round} / {totalRounds}
        </span>
        <span style={{ fontSize: 14 }}>🥊</span>
      </div>
    </div>
  );
}

function VerdictCard({ match }) {
  const isDraw = match.winner === "DRAW";
  const isProWin = match.winner === "PRO";
  const winColor = isDraw ? "#fbbf24" : isProWin ? match.pro.color : match.con.color;
  const headline = isDraw
    ? "DRAW — Judge calls it even"
    : `${match.winner} WINS — ${isProWin ? match.pro.emoji : match.con.emoji} ${isProWin ? match.pro.model : match.con.model}`;
  const icon = isDraw ? "⚖️" : "🏆";
  return (
    <div style={{
      background: `linear-gradient(135deg, ${winColor}11, ${winColor}08)`,
      border: `1px solid ${winColor}44`,
      borderRadius: 16, padding: 24, marginTop: 16,
      animation: "verdictIn 0.8s ease-out both",
    }}>
      <div style={{ textAlign: "center", marginBottom: 12 }}>
        <span style={{ fontSize: 40 }}>{icon}</span>
      </div>
      <div style={{ textAlign: "center", fontSize: 22, fontWeight: 800, color: winColor, marginBottom: 4, fontFamily: "'Space Mono', monospace" }}>
        {headline}
      </div>
      <div style={{ textAlign: "center", fontSize: 13, color: "#94a3b8", marginBottom: 12 }}>
        Confidence: {Math.round(match.confidence * 100)}%
      </div>
      <div style={{ fontSize: 13, color: "#cbd5e1", lineHeight: 1.6, fontStyle: "italic", textAlign: "center", maxWidth: 500, margin: "0 auto" }}>
        "{match.reasoning}"
      </div>
    </div>
  );
}

function ComparisonView() {
  const metrics = [
    { label: "Winner", m1: "PRO", m2: "DRAW", highlight: true },
    { label: "Confidence", m1: "60%", m2: "50%" },
    { label: "Deck run", m1: "Run 3 (materials ✓)", m2: "Run 4 (materials ✓)" },
    { label: "Source log", m1: MATCH1.logFile, m2: MATCH2.logFile },
    { label: "PRO model", m1: "Opus 4.7", m2: "Sonnet 4.6" },
    { label: "CON model", m1: "Sonnet 4.6", m2: "Opus 4.7" },
    { label: "Key PRO through-line", m1: "Sample efficiency + GSM-Symbolic brittleness", m2: "Grounding, 20 W unified models, trivial vs tricky failures" },
    { label: "Key CON through-line", m1: "Benchmark sweep + symmetric human fragility", m2: "Othello-GPT, ARC/GPQA breadth, bias catalog" },
  ];
  return (
    <div style={{ animation: "fadeIn 0.6s ease-out" }}>
      <h2 style={{ color: "#fbbf24", fontFamily: "'Space Mono', monospace", fontSize: 20, marginBottom: 20, textAlign: "center" }}>
        ⚖️ Match Comparison
      </h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 0, fontSize: 13 }}>
        <div style={{ padding: "10px 12px", borderBottom: "2px solid #fbbf2444", fontWeight: 700, color: "#94a3b8" }}></div>
        <div style={{ padding: "10px 12px", borderBottom: "2px solid #F9706644", fontWeight: 700, color: "#F97066", textAlign: "center" }}>Run 3 · Original</div>
        <div style={{ padding: "10px 12px", borderBottom: "2px solid #06B6D444", fontWeight: 700, color: "#06B6D4", textAlign: "center" }}>Run 4 · Swapped</div>
        {metrics.map((m, i) => (
          <React.Fragment key={`row-${i}`}>
            <div style={{ padding: "10px 12px", color: "#94a3b8", fontWeight: 600, borderBottom: "1px solid #ffffff0a", background: i % 2 === 0 ? "#ffffff04" : "transparent" }}>{m.label}</div>
            <div style={{ padding: "10px 12px", color: m.highlight ? "#fbbf24" : "#e2e8f0", textAlign: "center", borderBottom: "1px solid #ffffff0a", background: i % 2 === 0 ? "#ffffff04" : "transparent", fontWeight: m.highlight ? 700 : 400, wordBreak: "break-all" }}>{m.m1}</div>
            <div style={{ padding: "10px 12px", color: m.highlight ? "#fbbf24" : "#e2e8f0", textAlign: "center", borderBottom: "1px solid #ffffff0a", background: i % 2 === 0 ? "#ffffff04" : "transparent", fontWeight: m.highlight ? 700 : 400, wordBreak: "break-all" }}>{m.m2}</div>
          </React.Fragment>
        ))}
      </div>
      <div style={{
        marginTop: 24, padding: 20, borderRadius: 12,
        background: "linear-gradient(135deg, #fbbf2411, #fbbf2408)",
        border: "1px solid #fbbf2433",
      }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: "#fbbf24", marginBottom: 8 }}>💡 Key insight (Runs 3–4, with briefing pack)</div>
        <div style={{ fontSize: 13, color: "#cbd5e1", lineHeight: 1.7 }}>
          Shared materials let both sides cite tagged brief facts (for example CONTRAST/grounding, LLM/benchmarks).
          The same judge still awards PRO in the Opus-PRO cell, but a full swap yields a <em style={{ color: "#fbbf24" }}>DRAW</em> —
          evidence narrows the model gap without erasing it. Opus-on-CON never loses across all four study runs;
          transcripts in the replay match <code style={{ color: "#94a3b8" }}>logs/debate-20260503-093935-original.jsonl</code> and{" "}
          <code style={{ color: "#94a3b8" }}>logs/debate-20260503-094042-swapped.jsonl</code>.
        </div>
      </div>
    </div>
  );
}

function ProgressBar({ elapsed, total }) {
  const pct = Math.min((elapsed / total) * 100, 100);
  return (
    <div style={{ height: 4, background: "#ffffff0a", borderRadius: 2, overflow: "hidden", marginBottom: 8 }}>
      <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg, #fbbf24, #F97066)", transition: "width 0.3s", borderRadius: 2 }} />
    </div>
  );
}

// ── Main App ──
export default function DebateReplay() {
  const [mode, setMode] = useState("menu"); // menu | replay | compare
  const [activeMatch, setActiveMatch] = useState(null);
  const [visibleItems, setVisibleItems] = useState([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTyping, setCurrentTyping] = useState(null);
  const scrollRef = useRef(null);
  const abortRef = useRef(false);

  const scrollBottom = () => {
    setTimeout(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }); }, 50);
  };

  const playMatch = useCallback(async (match) => {
    setActiveMatch(match);
    setVisibleItems([]);
    setMode("replay");
    setIsPlaying(true);
    abortRef.current = false;
    await sleep(600);

    for (const round of match.rounds) {
      if (abortRef.current) break;
      setVisibleItems((prev) => [...prev, { type: "round", round: round.round }]);
      scrollBottom();
      await sleep(800);
      if (abortRef.current) break;

      // PRO speaks
      setVisibleItems((prev) => [...prev, { type: "speech", side: "left", ...match.pro, ...round.pro, typing: true }]);
      scrollBottom();
      await new Promise((resolve) => {
        setCurrentTyping(() => resolve);
      });
      if (abortRef.current) break;
      await sleep(400);

      // CON speaks
      setVisibleItems((prev) => [...prev, { type: "speech", side: "right", ...match.con, ...round.con, typing: true }]);
      scrollBottom();
      await new Promise((resolve) => {
        setCurrentTyping(() => resolve);
      });
      if (abortRef.current) break;
      await sleep(400);
    }

    if (!abortRef.current) {
      setVisibleItems((prev) => [...prev, { type: "verdict" }]);
      scrollBottom();
    }
    setIsPlaying(false);
  }, []);

  const skipToEnd = () => {
    if (!activeMatch) return;
    abortRef.current = true;
    const items = [];
    activeMatch.rounds.forEach((round) => {
      items.push({ type: "round", round: round.round });
      items.push({ type: "speech", side: "left", ...activeMatch.pro, ...round.pro, typing: false });
      items.push({ type: "speech", side: "right", ...activeMatch.con, ...round.con, typing: false });
    });
    items.push({ type: "verdict" });
    setVisibleItems(items);
    setIsPlaying(false);
    scrollBottom();
  };

  const elapsed = activeMatch
    ? visibleItems.filter((v) => v.type === "speech").length * 60
    : 0;

  return (
    <div style={{
      minHeight: "100vh", background: "#0a0a14",
      color: "#e2e8f0", fontFamily: "'Libre Baskerville', Georgia, serif",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Space+Mono:wght@400;700&display=swap');
        @keyframes blink { 0%, 100% { opacity: 1 } 50% { opacity: 0 } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px) } to { opacity: 1; transform: translateY(0) } }
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes verdictIn { from { opacity: 0; transform: scale(0.9) } to { opacity: 1; transform: scale(1) } }
        @keyframes float { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-8px) } }
        @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 currentColor } 50% { box-shadow: 0 0 20px 4px currentColor } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px }
        ::-webkit-scrollbar-track { background: transparent }
        ::-webkit-scrollbar-thumb { background: #ffffff22; border-radius: 3px }
      `}</style>

      {/* Header */}
      <div style={{
        position: "sticky", top: 0, zIndex: 10,
        background: "linear-gradient(180deg, #0a0a14 60%, #0a0a1400)",
        padding: "16px 24px 24px",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 28 }}>🧠</span>
            <span style={{ fontSize: 11, letterSpacing: 3, fontWeight: 700, color: "#fbbf24", fontFamily: "'Space Mono', monospace" }}>VS</span>
            <span style={{ fontSize: 28 }}>🤖</span>
            <span style={{ fontSize: 16, fontWeight: 700, color: "#e2e8f0", marginLeft: 8, fontFamily: "'Space Mono', monospace" }}>
              {mode === "menu" ? "AI DEBATE ARENA" : mode === "compare" ? "COMPARISON" : activeMatch?.title}
            </span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {mode !== "menu" && (
              <button onClick={() => { abortRef.current = true; setMode("menu"); setIsPlaying(false); }} style={{
                background: "#ffffff11", border: "1px solid #ffffff22", borderRadius: 8,
                color: "#94a3b8", padding: "6px 14px", cursor: "pointer", fontSize: 12,
                fontFamily: "'Space Mono', monospace",
              }}>← Menu</button>
            )}
            {mode === "replay" && isPlaying && (
              <button onClick={skipToEnd} style={{
                background: "#fbbf2422", border: "1px solid #fbbf2444", borderRadius: 8,
                color: "#fbbf24", padding: "6px 14px", cursor: "pointer", fontSize: 12,
                fontFamily: "'Space Mono', monospace",
              }}>Skip ⏩</button>
            )}
          </div>
        </div>
        {mode === "replay" && (
          <div style={{ marginTop: 12 }}>
            <ProgressBar elapsed={elapsed} total={480} />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#64748B", fontFamily: "'Space Mono', monospace" }}>
              <span>{Math.round(elapsed)}s elapsed</span>
              <span>480s budget</span>
            </div>
          </div>
        )}
      </div>

      {/* Menu */}
      {mode === "menu" && (
        <div style={{ padding: "40px 24px", maxWidth: 600, margin: "0 auto", animation: "fadeIn 0.5s ease-out" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ fontSize: 42, marginBottom: 16, animation: "float 3s ease-in-out infinite" }}>🥊</div>
            <h1 style={{ fontSize: 28, fontWeight: 700, color: "#fbbf24", fontFamily: "'Space Mono', monospace", lineHeight: 1.3 }}>
              Are Human Brains<br />Smarter Than LLMs?
            </h1>
            <p style={{ fontSize: 14, color: "#94a3b8", marginTop: 12 }}>
              Transcripts are from Run 3 and Run 4 (shared briefing materials):<br />
              <code style={{ fontSize: 11, color: "#64748B" }}>debate-20260503-093935-original.jsonl</code> ·{" "}
              <code style={{ fontSize: 11, color: "#64748B" }}>debate-20260503-094042-swapped.jsonl</code>
            </p>
          </div>

          {[MATCH1, MATCH2].map((match, i) => {
            const isProWin = match.winner === "PRO";
            const isDraw = match.winner === "DRAW";
            const resultLabel = isDraw ? "DRAW" : `${match.winner} wins`;
            const resultColor = isDraw ? "#fbbf24" : isProWin ? match.pro.color : match.con.color;
            return (
              <button key={i} onClick={() => playMatch(match)} style={{
                display: "block", width: "100%", textAlign: "left", cursor: "pointer",
                background: "linear-gradient(135deg, #ffffff06, #ffffff03)",
                border: "1px solid #ffffff15", borderRadius: 16, padding: 24,
                marginBottom: 16, transition: "all 0.2s",
                position: "relative", overflow: "hidden",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#fbbf2466"; e.currentTarget.style.transform = "translateY(-2px)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#ffffff15"; e.currentTarget.style.transform = "translateY(0)"; }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 700, color: "#e2e8f0", fontFamily: "'Space Mono', monospace", marginBottom: 6 }}>
                      ▶ {match.title}
                    </div>
                    <div style={{ fontSize: 13, color: "#94a3b8" }}>
                      {match.pro.emoji} {match.pro.model} (PRO) vs {match.con.emoji} {match.con.model} (CON)
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: resultColor }}>
                      {resultLabel}
                    </div>
                    <div style={{ fontSize: 11, color: "#64748B" }}>{Math.round(match.confidence * 100)}% conf.</div>
                  </div>
                </div>
              </button>
            );
          })}

          <button onClick={() => setMode("compare")} style={{
            display: "block", width: "100%", textAlign: "center", cursor: "pointer",
            background: "linear-gradient(135deg, #fbbf2411, #fbbf2408)",
            border: "1px solid #fbbf2433", borderRadius: 16, padding: 20,
            marginTop: 8, fontSize: 15, fontWeight: 700, color: "#fbbf24",
            fontFamily: "'Space Mono', monospace", transition: "all 0.2s",
          }}
          onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#fbbf24"; e.currentTarget.style.transform = "translateY(-2px)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#fbbf2433"; e.currentTarget.style.transform = "translateY(0)"; }}
          >
            ⚖️ Compare Both Matches
          </button>
        </div>
      )}

      {/* Replay */}
      {mode === "replay" && activeMatch && (
        <div ref={scrollRef} style={{ padding: "0 24px 100px", maxWidth: 700, margin: "0 auto", overflow: "auto" }}>
          {visibleItems.map((item, i) => {
            if (item.type === "round") return <RoundBadge key={i} round={item.round} totalRounds={4} />;
            if (item.type === "verdict") return <VerdictCard key={i} match={activeMatch} />;
            if (item.type === "speech") {
              const isLast = i === visibleItems.length - 1;
              return (
                <SpeechBubble
                  key={i}
                  side={item.side}
                  emoji={item.emoji}
                  model={item.model}
                  text={item.text}
                  color={item.color}
                  tokens={item.tokens}
                  wallS={item.wall_s}
                  typing={item.typing && isLast}
                  onDone={isLast && currentTyping ? currentTyping : undefined}
                />
              );
            }
            return null;
          })}
        </div>
      )}

      {/* Compare */}
      {mode === "compare" && (
        <div style={{ padding: "0 24px 60px", maxWidth: 800, margin: "0 auto" }}>
          <ComparisonView />
        </div>
      )}
    </div>
  );
}
