"""Shared evidence pack for the debate.

Both PRO and CON receive the SAME briefing in their system prompt, so the debate
hinges on argument quality and selection — not on evidence asymmetry.

Topic codes (cite by tag, e.g. 'as the brief notes on LLM/sample-efficiency…'):
  HUMAN/...     facts about the human brain, mind, and learning
  LLM/...       facts about transformer LLMs and their training pipeline
  CONTRAST/...  direct head-to-head comparisons (mechanism, scale, capability)

Sources are drawn from established cognitive-science and ML literature.
Where an effect is debated in the field, we say so explicitly.
"""

# ── HUMAN COGNITION ────────────────────────────────────────────────────────
HUMAN = [
    {
        "tag": "HUMAN/architecture",
        "title": "Neural hardware",
        "leaning": "neutral",
        "facts": [
            "~86 billion neurons (Herculano-Houzel 2009, revised down from the older 100B figure); ~10^14 synapses; massively parallel.",
            "Operates on ~20 W of power; per-neuron firing rates max ~200 Hz — five orders of magnitude slower than silicon clocks.",
            "Cortical columns are widely treated as the repeated computational unit (Mountcastle 1957); no central CPU.",
            "Plasticity is local: Hebbian learning ('cells that fire together wire together'), spike-timing-dependent plasticity, and neuromodulation by dopamine error signals.",
        ],
    },
    {
        "tag": "HUMAN/working-memory",
        "title": "Working memory",
        "leaning": "con",
        "facts": [
            "Capacity ~4 chunks (Cowan 2001), revising Miller's classic 7±2 (1956).",
            "Baddeley's model: phonological loop + visuospatial sketchpad + episodic buffer + central executive.",
            "Severe serial bottleneck: only one or two novel items can be actively manipulated at once.",
            "Decays in seconds without rehearsal; chunking expands effective capacity by recoding into known units.",
        ],
    },
    {
        "tag": "HUMAN/long-term-memory",
        "title": "Long-term memory",
        "leaning": "neutral",
        "facts": [
            "Tulving's taxonomy: episodic (events), semantic (facts), procedural (skills) — distinct neural substrates.",
            "Encoded via long-term potentiation/depression at synapses; consolidated via hippocampus → neocortex transfer over weeks–years.",
            "Slow-wave and REM sleep are causally implicated in consolidation (Walker & Stickgold 2004).",
            "Capacity is effectively unbounded for normal lifespans; forgetting follows a power-law curve (Wixted 2004).",
        ],
    },
    {
        "tag": "HUMAN/encoding-retrieval",
        "title": "Encoding and retrieval",
        "leaning": "neutral",
        "facts": [
            "Depth-of-processing: semantic encoding produces stronger recall than surface (Craik & Lockhart 1972).",
            "Retrieval is reconstructive, not playback — false memories arise routinely (Loftus 1974; the misinformation effect).",
            "Encoding-specificity: recall depends on overlap between encoding context and retrieval cue (Tulving & Thomson 1973).",
            "Spacing effect: distributed practice yields stronger long-term retention than massed practice (Ebbinghaus 1885; replicated continuously).",
            "Testing effect: retrieval itself strengthens the trace (Roediger & Karpicke 2006).",
        ],
    },
    {
        "tag": "HUMAN/learning",
        "title": "Learning and development",
        "leaning": "pro",
        "facts": [
            "Children acquire native language from ~10–50 million words by age 5 (Hart & Risley 1995; later replications by Frank et al. give similar order-of-magnitude estimates).",
            "One-shot generalization is routine: a child sees one giraffe and recognizes others, including in cartoons.",
            "Curriculum is embodied, multimodal, and active — closed-loop feedback with the physical world from infancy.",
            "Critical periods exist for language and binocular vision (Hubel & Wiesel); later acquisition is non-native.",
            "Causal-model construction develops early: toddlers run interventionist experiments on objects (Gopnik 2012).",
        ],
    },
    {
        "tag": "HUMAN/reasoning",
        "title": "Reasoning and metacognition",
        "leaning": "pro",
        "facts": [
            "Dual-process: fast intuitive System 1 vs slow deliberative System 2 (Kahneman 2011).",
            "Explicit metacognition: feeling-of-knowing, confidence judgments, source monitoring — humans know what they don't know, often.",
            "Symbol grounding: human concepts are grounded in sensorimotor experience (Harnad 1990; Barsalou 1999; Lakoff & Johnson 1980).",
            "Theory-of-mind, common-sense physics, and pragmatic inference develop without explicit instruction.",
        ],
    },
    {
        "tag": "HUMAN/limits",
        "title": "Documented human failure modes",
        "leaning": "con",
        "facts": [
            "Cognitive biases: anchoring, confirmation, availability, hindsight, framing (Tversky & Kahneman 1974 onward).",
            "Dunning-Kruger: low-skill individuals overestimate their competence; high-skill underestimate (Kruger & Dunning 1999).",
            "Fatigue/depletion effects: judges granted parole more often after meals (Danziger et al. 2011) — effect size since debated, but the result is real.",
            "Eyewitness testimony is unreliable; ~70% of DNA-overturned wrongful convictions involved eyewitness error (Innocence Project).",
            "Capacity-limited attention: change blindness, inattentional blindness (Simons & Chabris 1999).",
        ],
    },
]

# ── LARGE LANGUAGE MODELS ──────────────────────────────────────────────────
LLM = [
    {
        "tag": "LLM/architecture",
        "title": "Transformer architecture",
        "leaning": "neutral",
        "facts": [
            "Self-attention (Vaswani et al. 2017): each token attends to every other in context; cost is O(n²) in sequence length.",
            "Multi-head attention: parallel attention subspaces capture different syntactic/semantic relations.",
            "Decoder-only LLMs are autoregressive: predict the next token given the prefix; loss = cross-entropy on next-token prediction.",
            "Stack of identical blocks: pre-norm + multi-head attention + residual + feed-forward MLP + residual; positions encoded via RoPE / ALiBi / learned embeddings.",
            "Activations are dense vectors in R^d (d ≈ 4k–16k for frontier models); no explicit symbolic structure.",
        ],
    },
    {
        "tag": "LLM/training",
        "title": "Training pipeline",
        "leaning": "neutral",
        "facts": [
            "Pretraining: SGD/AdamW on cross-entropy of next-token prediction over web-scale corpora (CommonCrawl + books + code + curated).",
            "Frontier scale: ~10^12–10^13 training tokens, ~10^11–10^12 parameters, ~10^25 training FLOPs.",
            "Chinchilla scaling laws (Hoffmann et al. 2022): compute-optimal models balance parameters and tokens at ~20 tokens/parameter.",
            "Post-training: SFT on human demonstrations → RLHF / RLAIF / DPO to align outputs with preferences and reduce hallucination (Ouyang et al. 2022; Bai et al. 2022).",
            "Backpropagation through millions of steps is biologically implausible — no known cortical mechanism implements global error signals at scale.",
        ],
    },
    {
        "tag": "LLM/sample-efficiency",
        "title": "Sample efficiency",
        "leaning": "pro",
        "facts": [
            "Frontier LLMs train on ~10^13 tokens; a human gets ~10^7 words of linguistic input by age 5 — roughly 6 orders of magnitude less.",
            "Per-FLOP, biological learning is dramatically more sample-efficient at language acquisition.",
            "Fine-tuning typically needs 10^3–10^5 examples; in-context learning with a few examples is now competitive on many tasks (Brown et al. 2020).",
            "Caveat: an individual human starts with ~600M years of evolutionary 'pretraining' encoded in genome and developmental priors.",
        ],
    },
    {
        "tag": "LLM/working-memory",
        "title": "Context window as working memory",
        "leaning": "neutral",
        "facts": [
            "Context windows now span 200K–2M tokens (Claude, Gemini); attention provides content-addressable access across the whole window.",
            "But context is volatile: nothing persists across sessions unless explicitly fed back in.",
            "'Lost in the middle' (Liu et al. 2023): retrieval accuracy is highest at the start and end of context, lower in the middle.",
            "No native consolidation: weights are frozen at inference; new facts require fine-tuning or external retrieval.",
        ],
    },
    {
        "tag": "LLM/representations",
        "title": "Internal representations",
        "leaning": "neutral",
        "facts": [
            "Distributed embeddings: meaning is encoded as positions and directions in high-dimensional vector space.",
            "Linear probes recover concepts (gender, sentiment, geography, time) from intermediate activations (Tenney et al. 2019; Gurnee & Tegmark 2024).",
            "Mechanistic interpretability finds 'features' that resemble human concepts (Anthropic Sparse Autoencoders, 2024).",
            "No explicit episodic memory: training data is not stored as discrete retrievable events; training-set extraction is possible but rare and statistical (Carlini et al. 2021).",
        ],
    },
    {
        "tag": "LLM/retrieval-and-inference",
        "title": "Retrieval and inference",
        "leaning": "pro",
        "facts": [
            "Attention is a soft, content-addressable retrieval over the context window.",
            "Inference is a fixed forward pass per token; iterative reasoning requires explicit chaining (chain-of-thought, agents, scratchpads).",
            "Retrieval-Augmented Generation (RAG) supplies external memory via vector stores — engineering glue, not native long-term memory.",
            "Hallucination rate climbs sharply at the edges of the training distribution (out-of-distribution prompts).",
        ],
    },
    {
        "tag": "LLM/limits",
        "title": "Documented LLM failure modes",
        "leaning": "pro",
        "facts": [
            "GSM-Symbolic (Mirzadeh et al. 2024, Apple): renaming variables and numbers in math word-problems drops accuracy 30–65% — fragile under distribution shift.",
            "Tokenization artifacts: trouble counting letters in 'strawberry', long-multiplication, reversal of names — all symptomatic of subword tokenization.",
            "Catastrophic forgetting under continued training; no native online learning.",
            "Unfaithful chain-of-thought (Turpin et al. 2023): verbalized reasoning often does not reflect the actual computation driving the answer.",
            "Sycophancy and reward-hacking emerge from RLHF (Sharma et al. 2023).",
        ],
    },
    {
        "tag": "LLM/benchmarks",
        "title": "Benchmark performance (frontier as of 2024–2025)",
        "leaning": "con",
        "facts": [
            "GPT-4-class: 90th-percentile bar exam, 88th LSAT, top-decile USMLE Step 1, ~86% MMLU.",
            "GPQA Diamond (graduate-level science with Google-proof questions): frontier models match domain experts.",
            "ARC-AGI (held-out abstract reasoning): o3 reached ~87% on the public set — above the 85% adult-human baseline — at very high compute cost per problem.",
            "FrontierMath (research-level math): o3 solved ~25%; Terence Tao described the problems as 'extremely hard'.",
            "Humanity's Last Exam (multidisciplinary expert): frontier models still well below human-expert performance as of late 2024.",
        ],
    },
]

# ── HEAD-TO-HEAD CONTRASTS ─────────────────────────────────────────────────
CONTRAST = [
    {
        "tag": "CONTRAST/mechanism",
        "title": "Learning mechanisms",
        "leaning": "pro",
        "facts": [
            "Brain: local Hebbian/STDP plasticity + neuromodulator-gated learning; embodied closed-loop feedback.",
            "LLM: global gradient backpropagation through the full computational graph during pretraining; static at inference.",
            "Brain learns continuously across the lifespan; LLM weights are frozen post-training unless explicitly fine-tuned.",
            "Brain integrates modalities natively at the cortical level; multimodal LLMs concatenate modality-specific encoders into a shared transformer.",
        ],
    },
    {
        "tag": "CONTRAST/grounding",
        "title": "Symbol grounding",
        "leaning": "pro",
        "facts": [
            "Harnad's symbol grounding problem: symbols must connect to non-symbolic referents to carry meaning.",
            "Human concepts are grounded in sensorimotor experience and embodied affordances (Barsalou; Lakoff & Johnson).",
            "LLM concepts are grounded only in token co-occurrence — second-order grounding via human-written text.",
            "Open empirical question: whether internet-scale text suffices to recover an implicit world model adequate for reasoning (Andreas 2022; Li et al. 2023 'Othello-GPT').",
        ],
    },
    {
        "tag": "CONTRAST/calibration",
        "title": "Calibration and metacognition",
        "leaning": "neutral",
        "facts": [
            "Humans show explicit metacognition (feeling-of-knowing, source monitoring) — but exhibit overconfidence and Dunning-Kruger.",
            "LLMs after RLHF are reasonably calibrated on in-distribution multiple-choice (Kadavath et al. 2022) but uncalibrated on out-of-distribution prompts.",
            "Humans can self-correct upon reflection and external feedback within a single problem.",
            "LLMs can be prompted for self-critique (Constitutional AI, self-refine) but lack persistent self-modeling across sessions.",
        ],
    },
    {
        "tag": "CONTRAST/energy-and-scale",
        "title": "Energy and lifetime cost",
        "leaning": "pro",
        "facts": [
            "Brain: ~20 W continuous; ~86B neurons; lifetime sensory experience on the order of 10^9–10^10 seconds.",
            "Frontier model training: tens of MW for weeks; ~10^25 FLOPs; multi-megawatt inference fleets at deployment.",
            "Per-task inference energy may favor LLMs on standardized text tasks; per-capability acquisition energy heavily favors brains.",
            "Brain costs are evolutionarily and developmentally amortized over generations; LLM costs are explicit and dollar-denominated.",
        ],
    },
    {
        "tag": "CONTRAST/generalization",
        "title": "Generalization and novelty",
        "leaning": "pro",
        "facts": [
            "Humans show strong systematic generalization: novel sentences, novel tools, novel social situations.",
            "LLMs show strong interpolative generalization within the training distribution; fragile under structured shifts (GSM-Symbolic).",
            "Humans solve abstract visual puzzles (ARC-AGI) at ~85% with seconds of inspection; LLMs reach comparable levels only with massive test-time compute.",
            "Humans produce genuinely novel scientific theories (general relativity, natural selection); LLMs have not yet produced a comparable original theory unaided.",
        ],
    },
]

ALL_SECTIONS = [
    ("HUMAN COGNITION", HUMAN),
    ("LARGE LANGUAGE MODELS", LLM),
    ("HEAD-TO-HEAD CONTRASTS", CONTRAST),
]


def format_briefing() -> str:
    """Render the briefing as plain text for injection into a system prompt."""
    out = []
    for section_title, items in ALL_SECTIONS:
        out.append(f"### {section_title} ###")
        for item in items:
            out.append(f"[{item['tag']}] {item['title']}")
            for f in item["facts"]:
                out.append(f"  • {f}")
            out.append("")
    return "\n".join(out).rstrip() + "\n"


def stats() -> dict:
    """Return summary stats — useful for logging at run-start."""
    text = format_briefing()
    n_topics = sum(len(items) for _, items in ALL_SECTIONS)
    n_facts = sum(len(item["facts"]) for _, items in ALL_SECTIONS for item in items)
    items_flat = [item for _, items in ALL_SECTIONS for item in items]
    pro_leaning = sum(1 for it in items_flat if it.get("leaning") == "pro")
    con_leaning = sum(1 for it in items_flat if it.get("leaning") == "con")
    neutral     = sum(1 for it in items_flat if it.get("leaning") == "neutral")
    return {
        "sections": len(ALL_SECTIONS),
        "n_topics": n_topics,
        "n_facts": n_facts,
        "word_count": len(text.split()),
        "chars": len(text),
        "approx_tokens": len(text) // 4,
        "pro_leaning": pro_leaning,
        "con_leaning": con_leaning,
        "neutral": neutral,
    }


if __name__ == "__main__":
    import json as _json
    print(format_briefing())
    print()
    print("STATS:", _json.dumps(stats(), indent=2))
