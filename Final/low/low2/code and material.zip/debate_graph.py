"""LangGraph debate: 'human brain is smarter than LLM' (PRO) vs 'LLM ≥ human' (CON).

Nodes:  pro_debater → recorder_pro → con_debater → recorder_con → [continue?] → summarizer → judge
Recorder writes a structured JSONL log + prints the live transcript.
At the end, a visualization step renders a timeline of the run.

Env:
    DEBATE_SWAP=1   swap PRO and CON model assignments (compare model influence)
"""

import os, json, time, datetime, pathlib
from typing import TypedDict, Annotated, Literal
from operator import add

from langgraph.graph import StateGraph, START, END
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import SystemMessage, HumanMessage

import materials  # shared evidence pack
BRIEFING = materials.format_briefing()
BRIEFING_STATS = materials.stats()

TOKENS_PER_SECOND = 2.5  # ~150 wpm * 1 token/word

# ── Run config ─────────────────────────────────────────────────────────────
SWAP = os.environ.get("DEBATE_SWAP", "0") == "1"
RUN_ID = datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ("-swapped" if SWAP else "-original")
LOG_DIR = pathlib.Path("/Users/zhangshujuan/LLM/agent/logs")
LOG_DIR.mkdir(exist_ok=True)
LOG_PATH = LOG_DIR / f"debate-{RUN_ID}.jsonl"

OPUS    = "claude-opus-4-7"
SONNET  = "claude-sonnet-4-6"
HAIKU   = "claude-haiku-4-5-20251001"

PRO_MODEL = SONNET if SWAP else OPUS
CON_MODEL = OPUS   if SWAP else SONNET

def _make_llm(model, temperature=None):
    # Opus 4.7 deprecated `temperature` — handle that quirk.
    if model == OPUS:
        return ChatAnthropic(model=model)
    return ChatAnthropic(model=model, temperature=temperature)

# ── State ──────────────────────────────────────────────────────────────────
class DebateTurn(TypedDict):
    speaker: Literal["pro", "con"]
    round: int
    text: str
    seconds: float
    tokens: int
    model: str

class DebateState(TypedDict):
    topic: str
    transcript: Annotated[list, add]   # reducer = append
    round: int
    max_rounds: int
    elapsed_s: float
    budget_s: float
    summary: str
    verdict: str

# ── LLMs ──────────────────────────────────────────────────────────────────
pro_llm        = _make_llm(PRO_MODEL, 0.7)
con_llm        = _make_llm(CON_MODEL, 0.7)
summarizer_llm = _make_llm(HAIKU, 0.3)
judge_llm      = _make_llm(OPUS)

_BRIEFING_BLOCK = (
    "\n\n=== REFERENCE MATERIALS (shared with both sides) ===\n"
    "You may cite, paraphrase, or rebut any of the following. Both sides have access to "
    "identical materials, so the debate hinges on argument quality and selection — not on "
    "evidence asymmetry. Prefer specific facts from this brief over rhetorical claims; cite "
    "the topic tag in shorthand (e.g. 'as the brief notes on LLM/limits…').\n\n"
    f"{BRIEFING}\n=== END REFERENCE MATERIALS ==="
)

PRO_SYS = ("You are PRO. Argue: the HUMAN BRAIN is smarter than any LLM. "
           "Use embodied cognition, causal reasoning, common sense, creativity, emotion, "
           "and the gap between pattern-matching and understanding. "
           "Directly rebut your opponent's last turn. Stay within your time budget. "
           "Be punchy and specific — no fluff." + _BRIEFING_BLOCK)
CON_SYS = ("You are CON. Argue: LLMs match or exceed the human brain on intelligence-relevant tasks. "
           "Use benchmarks, breadth, speed, scaling, and the unreliability of human cognition "
           "(biases, fatigue, narrow expertise). "
           "Directly rebut your opponent's last turn. Stay within your time budget. "
           "Be punchy and specific — no fluff." + _BRIEFING_BLOCK)

# ── Helpers ────────────────────────────────────────────────────────────────
def _history(t):
    if not t:
        return "(no prior turns — give your OPENING statement)"
    return "\n\n".join(f"[{x['speaker'].upper()} R{x['round']}] {x['text']}" for x in t)

def _budget(round_idx, max_rounds):
    if round_idx == 1:           return 75.0
    if round_idx == max_rounds:  return 45.0
    return 60.0

def _extract_text(resp):
    return resp.content if isinstance(resp.content, str) else "".join(
        b.get("text", "") for b in resp.content if isinstance(b, dict))

def _extract_out_tokens(resp):
    um = getattr(resp, "usage_metadata", None) or {}
    return int(um.get("output_tokens", 0))

# ── Nodes ──────────────────────────────────────────────────────────────────
def make_debater(side, llm, sys, model):
    def node(s):
        secs = _budget(s["round"], s["max_rounds"])
        max_tok = int(secs * TOKENS_PER_SECOND)
        prompt = (f"Topic: {s['topic']}\n"
                  f"You are {side.upper()}. Round {s['round']}/{s['max_rounds']} — "
                  f"~{secs:.0f}s budget (~{max_tok} tokens).\n\n"
                  f"Debate so far:\n{_history(s['transcript'])}\n\nSpeak now.")
        bound = llm.bind(max_tokens=max_tok)
        t0 = time.time()
        resp = bound.invoke([SystemMessage(content=sys), HumanMessage(content=prompt)])
        wall = time.time() - t0
        turn = {
            "speaker": side, "round": s["round"],
            "text": _extract_text(resp), "seconds": secs,
            "tokens": _extract_out_tokens(resp), "model": model,
            "wall_s": round(wall, 2),
        }
        return {"transcript": [turn], "elapsed_s": s["elapsed_s"] + secs}
    return node

def recorder(s):
    """Logger node — writes one JSONL line per turn AND echoes to console."""
    last = s["transcript"][-1]
    entry = {
        "ts": datetime.datetime.now().isoformat(timespec="seconds"),
        "elapsed_s": s["elapsed_s"],
        "budget_s": s["budget_s"],
        "round": last["round"],
        "speaker": last["speaker"],
        "model": last["model"],
        "seconds_budget": last["seconds"],
        "wall_s": last.get("wall_s"),
        "out_tokens": last["tokens"],
        "text": last["text"],
    }
    with LOG_PATH.open("a") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    bar = "─" * 78
    print(f"\n{bar}")
    print(f"[t≈{s['elapsed_s']:>5.0f}/{s['budget_s']:.0f}s]  "
          f"{last['speaker'].upper()}  R{last['round']}  "
          f"({last['seconds']:.0f}s budget, {last['tokens']} tokens, model={last['model']}, "
          f"wall={last.get('wall_s', '?')}s)")
    print(bar)
    print(last["text"])
    return {"round": s["round"] + 1} if last["speaker"] == "con" else {}

def summarizer(s):
    print("\n\n========================  SUMMARIZER (haiku)  ========================")
    resp = summarizer_llm.bind(max_tokens=600).invoke([
        SystemMessage(content="List each side's 3 strongest points as concise bullets. No verdict, no opinion."),
        HumanMessage(content=f"Topic: {s['topic']}\n\nFull transcript:\n{_history(s['transcript'])}"),
    ])
    text = _extract_text(resp)
    print(text)
    with LOG_PATH.open("a") as f:
        f.write(json.dumps({"phase": "summary", "text": text}, ensure_ascii=False) + "\n")
    return {"summary": text}

def judge(s):
    print("\n\n==========================  JUDGE (opus)  ===========================")
    resp = judge_llm.bind(max_tokens=400).invoke([
        SystemMessage(content=("You are a neutral debate judge. Output exactly:\n"
                               "WINNER: <PRO|CON|DRAW>\n"
                               "CONFIDENCE: <0.0-1.0>\n"
                               "REASONING: <one paragraph, 4-6 sentences>\n\n"
                               "Judge purely on argument quality, evidence, and rebuttal — "
                               "do NOT inject your own beliefs about humans vs LLMs.")),
        HumanMessage(content=f"Topic: {s['topic']}\n\nSummary of arguments:\n{s['summary']}"),
    ])
    text = _extract_text(resp)
    print(text)
    with LOG_PATH.open("a") as f:
        f.write(json.dumps({"phase": "verdict", "text": text}, ensure_ascii=False) + "\n")
    return {"verdict": text}

def should_continue(s) -> Literal["pro_debater", "summarizer"]:
    if s["round"] > s["max_rounds"]:           return "summarizer"
    if s["elapsed_s"] >= s["budget_s"] - 30:   return "summarizer"
    return "pro_debater"

# ── Visualization ──────────────────────────────────────────────────────────
def visualize(final):
    bar_w = 48
    budget = final["budget_s"]
    print("\n\n══════════════════════════════════  PROCESS VISUALIZATION  ═══════════════════════════════════")
    print(f"  config: PRO={PRO_MODEL}   CON={CON_MODEL}   {'(SWAPPED)' if SWAP else '(original)'}")
    print(f"  briefing loaded into both system prompts: "
          f"{BRIEFING_STATS['n_facts']} facts, {BRIEFING_STATS['word_count']} words")
    print(f"  log file: {LOG_PATH}")
    print()
    print(f"  Per-turn timeline (bar width ∝ time-budget; tokens shown right of bar):")
    print(f"  {'turn':<10}{'speaker':<6}{'model':<32}|{'time bar':<{bar_w+2}}|  budget  tok    wall")
    print(f"  {'─'*10}{'─'*6}{'─'*32}+{'─'*(bar_w+2)}+{'─'*30}")
    cum = 0.0
    for t in final["transcript"]:
        w = max(1, int(round(t["seconds"]/budget * bar_w)))
        glyph = "█" if t["speaker"] == "pro" else "▒"
        bar = glyph * w + " " * (bar_w - w)
        print(f"  R{t['round']:<9}{t['speaker'].upper():<6}{t['model']:<32}| {bar} |  {t['seconds']:>4.0f}s  {t['tokens']:>4d}tok {t.get('wall_s',0):>5.1f}s")
        cum += t["seconds"]
    print(f"  {'TOTAL':<10}{'':<6}{'':<32}+{'─'*(bar_w+2)}+")
    print(f"  {'':<48}{cum:>4.0f}s / {budget:.0f}s budget consumed")

    # Cumulative position bar (which speaker holds the floor at each second)
    print()
    print(f"  Speaker-by-second view  (█=PRO  ▒=CON   each '·' below ≈ {budget/bar_w:.0f}s of debate)")
    line = ""
    for t in final["transcript"]:
        w = max(1, int(round(t["seconds"]/budget * bar_w)))
        line += ("█" if t["speaker"] == "pro" else "▒") * w
    print(f"  0s {line[:bar_w]} {budget:.0f}s")

    # Token efficiency
    pro_tok = sum(t["tokens"] for t in final["transcript"] if t["speaker"] == "pro")
    con_tok = sum(t["tokens"] for t in final["transcript"] if t["speaker"] == "con")
    pro_wall = sum(t.get("wall_s", 0) for t in final["transcript"] if t["speaker"] == "pro")
    con_wall = sum(t.get("wall_s", 0) for t in final["transcript"] if t["speaker"] == "con")
    print()
    print(f"  PRO ({PRO_MODEL}):  {pro_tok} output tokens, {pro_wall:.1f}s wall-clock LLM time")
    print(f"  CON ({CON_MODEL}):  {con_tok} output tokens, {con_wall:.1f}s wall-clock LLM time")
    print()
    # Verdict snapshot
    v = final["verdict"].splitlines()[:2]
    print(f"  Verdict snapshot: {' | '.join(s.strip() for s in v)}")
    print("══════════════════════════════════════════════════════════════════════════════════════════════")

# ── Build graph ────────────────────────────────────────────────────────────
g = StateGraph(DebateState)
g.add_node("pro_debater",  make_debater("pro", pro_llm, PRO_SYS, PRO_MODEL))
g.add_node("con_debater",  make_debater("con", con_llm, CON_SYS, CON_MODEL))
g.add_node("recorder_pro", recorder)
g.add_node("recorder_con", recorder)
g.add_node("summarizer",   summarizer)
g.add_node("judge",        judge)

g.add_edge(START, "pro_debater")
g.add_edge("pro_debater",  "recorder_pro")
g.add_edge("recorder_pro", "con_debater")
g.add_edge("con_debater",  "recorder_con")
g.add_conditional_edges("recorder_con", should_continue,
                        {"pro_debater": "pro_debater", "summarizer": "summarizer"})
g.add_edge("summarizer", "judge")
g.add_edge("judge", END)

graph = g.compile()

# ── Run ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("================================================================================")
    print(f"  DEBATE  run_id={RUN_ID}")
    print(f"  Resolved: the human brain is smarter than any large language model.")
    print(f"  PRO={PRO_MODEL}    CON={CON_MODEL}    JUDGE={OPUS}    SUMMARIZER={HAIKU}")
    print(f"  briefing: {BRIEFING_STATS['n_facts']} facts across {BRIEFING_STATS['n_topics']} topics "
          f"({BRIEFING_STATS['pro_leaning']} pro / {BRIEFING_STATS['con_leaning']} con / "
          f"{BRIEFING_STATS['neutral']} neutral leans)  ~{BRIEFING_STATS['approx_tokens']} tokens")
    print(f"  log → {LOG_PATH}")
    print("================================================================================")
    # Persist the briefing to the JSONL log so the run is fully reconstructible.
    with LOG_PATH.open("a") as f:
        f.write(json.dumps({"phase": "briefing", **BRIEFING_STATS, "text": BRIEFING},
                           ensure_ascii=False) + "\n")
    initial = {
        "topic": "Resolved: the human brain is smarter than any large language model.",
        "transcript": [],
        "round": 1, "max_rounds": 4,
        "elapsed_s": 0.0, "budget_s": 480.0,
        "summary": "", "verdict": "",
    }
    final = graph.invoke(initial, config={"recursion_limit": 50})
    visualize(final)
